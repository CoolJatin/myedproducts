<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\admin;
use Validator;
use Auth;
use DB;
use Session;

class IndexController extends Controller
{
    protected $admin;
    public function __construct(){
        $this->admin = new admin();
    }

    public function index(){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product');
        $result['homecategory'] = $this->admin->GetbyDataCondition('categorys',['type'=>'home']);
        $result['about'] = $this->admin->SingalDatawitoutCondition('aboutus');
        $result['sale'] = $this->admin->GetbyDataCondition('product',['type'=>'1']);
        $result['saleoffer'] = $this->admin->SingalData('categorys','type','sale');
        return view('web.index',$result);
    }
    // login controller
    public function loginuser(Request $request){
        $validator = Validator::make($request->all(),[
           'email' => 'required',
           'password' => 'required',
        ]);
        if($validator->fails()) {
            return response()->json(['status'=>201,'error'=>$validator->errors()]);
        } else {
            $chack = DB::table('customer')->where('email',$request->email)->where('password',md5($request->password))->first();
            if(!empty($chack)){
                Session::put('id',$chack->id);
                DB::table('add_to_cart')->where('userid',Session::get('cartid'))->update(['userid'=>$chack->id]);
                return response()->json(['status'=>200,'success'=>'Login Successful!']);
            } else {
                return response()->json(['status'=>203,'wrongdetaisl'=>'User name and password do not match']);
            }
        }
    }

    public function myaccount(){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product');
        return view('web.account',$result);
    }

    public function register(Request $request){
        $validator = Validator::make($request->all(),[
            'email'=>'required',
            'name'=>'required',
            'password' => 'required',
            'cpassword' => 'required|same:password'
        ]);
        if($validator->fails()){
            return response()->json(['status'=>201,'error'=>$validator->errors()]);
        }  else {
        $chack = $this->admin->checkduplicateentry('customer','email',$request->email);
          if(empty($chack)){
              $data['name'] = $request->name;
              $data['email'] = $request->email;
              $data['password'] = md5($request->password);
              $result = $this->admin->insertdata('customer', $data);
              if ($result==1) {
                  return response()->json(['status'=>200,'success'=>'Registration Successful!']);
              } else {
                  return response()->json(['status'=>200,'success'=>'Query Not Run!']);
              }
          } else {
            return response()->json(['status'=>203,'email'=>'Email is already taken!']);
          }
        }
    }

    public function logoutuser(){
       session()->forget('id');
       return redirect('/');
    }

    public function page($slug){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['cats'] = $this->admin->SingalData('categorys','slug',$slug);
        $result['products'] = $this->admin->GetbyDataConditionpaginat('product',['catid'=> $result['cats']->id],'15');
        $result['productss'] = $this->admin->GetallData('product');
        return view('web.page',$result);
    }

    public function ShopProduct($slug){
        $result['productss'] = $this->admin->GetallData('product');
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['singaldata'] = $this->admin->SingalData('product','slug',$slug);
       return view('web.shop',$result);
    }

    public function Cart(){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product');
        $cart = $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('id')]);
        if($cart->count() > 0){
            $result['cart'] = $cart;
            return view('web.cart',$result);
        } else {
            $result['cart'] = $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('cartid')]);

            return view('web.cart',$result);
        }
    }

    public function remove($id=""){
        $result = $this->admin->RemoveItem('add_to_cart',$id);
        if($result==1){
            return redirect()->back()->with('success','remove Item Successful!');
        } else {
            return redirect()->back()->with('success','Query Not Run!!');
        }
    }
    public function checkout(){
        if(!empty(session::get('id'))){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product'); 
        $cart = $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('id')]);
        $cart = $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('id')]);
        if($cart->count() > 0){
            $result['cart'] = $cart;
        } else {
            $result['cart'] = $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('cartid')]);
        }

        return view('web.checkout',$result);
    }
        else {
            return redirect('myaccount');
        }
    }


    public function placeorder(Request $request){
       // dd($request->all());
        $orderid = uniqid();
        $this->validate($request, [
            "fname" =>"required",
            "lname" =>"required",
            "company" =>"required",
            "email" => "required",
            "street" => "required",
            "state" => "required",
            "address" => "required",
            "country" => "required",
            "pincode" => "required",
            "shippingaddress" => "required",
            "paymentMethod" => "required",
            'cardname' => 'required',
            'cardnumber' => 'required',
            'expiration' => 'required',
            'cvv' => 'required',
         ]);
         $data['fname'] = $request->fname;
         $data['lname'] = $request->lname;
         $data['company'] = $request->company;
         $data['email'] = $request->email;
         $data['street'] = $request->street;
         $data['state'] = $request->state;
         $data['address'] = $request->address;
         $data['country'] = $request->country;
         $data['shippingaddress'] = $request->shippingaddress;
         $data['paymentMethod'] = $request->paymentMethod;
         $data['cardname'] = $request->cardname;
         $data['cardnumber'] = $request->cardnumber;
         $data['expiration'] = $request->expiration;
         $data['cvv'] = $request->cvv;
         $data['datetime'] = date('Y/m/d');
         $data['orderid'] = $orderid;
         $data['userid'] = session::get('id');
         $result = $this->admin->insertdata('address',$data);
         if($result==1){
            $datads =  $this->MyOrder($orderid);
            return redirect('thankyou')->with('success','Address Successful Save!');
         } else {
            return redirect()->back()->with('success','Query Not Run!');
         }
    }

    public function MyOrder($orderid=""){
        if(!empty(session::get('id'))){
                $ids = array();
                $addtocart =  $this->admin->GetbyDataCondition('add_to_cart',['userid'=>session::get('id')]);
              //  dd($addtocart);
            foreach($addtocart as $itemaddtocat){
                array_push($ids,$itemaddtocat->id);
                $data['userid'] =$itemaddtocat->userid;
                $data['orderid'] = $orderid;
                $data['datetime'] = date('Y/m/d');
                $data['title'] = $itemaddtocat->title;
                $data['price'] = $itemaddtocat->price;
                $data['productid'] = $itemaddtocat->productid;
                $data['qty'] = $itemaddtocat->qty;
                $data['image'] = $itemaddtocat->image;
                $this->admin->insertdata('orders',$data);
            }
        } else {
            return redirect('myaccount');
        }
        $this->DeleteCart($ids);
    }

    public function DeleteCart($id){
        $data = DB::table('add_to_cart')->whereIn('id',$id)->delete();
        return $data;
    }
    
    
    public function about(){
         $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product');
        $result['about'] = $this->admin->GetAllData('aboutus');
        return view('web.about',$result);
    }
    
    public function shop(){
         $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
         $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
         $result['productss'] = $this->admin->GetallData('product');
         return view('web.shopall',$result);
    }
    
    public function myprice($id=""){
        $data = $this->admin->SingalData('multisize','id',$id);
        if(!empty($data)){
          return response()->json(['status'=>200,'data'=>$data]);
        } else {
            return response()->json(['status'=>201]);
        }
    }
    public function thankyou(){
        $result['category'] = $this->admin->LimtData('categorys','0','6','normal');
        $result['second'] = $this->admin->LimtData('categorys','6','100','normal');
        $result['productss'] = $this->admin->GetallData('product');
        $result['homecategory'] = $this->admin->GetbyDataCondition('categorys',['type'=>'home']);
        return view('web.thankyou',$result);
    }

}
