<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
.eroor{
    color:red;
}
</style>
<div class="owl-carousel owl-theme py-3">
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/buy-ritalin-20mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Ritalin 20mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/buy-ritalin-20mg-online/">Ritalin 20mg</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>180.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>740.00</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/oxycodone-m523-10325/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-150x150.png" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-150x150.png 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-100x100.png 100w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/oxycodone-m523-10325/">Oxycodone m523 10325</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>320.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>720.00</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/xanax/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Xanax 2mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/xanax/">Xanax 2mg</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>600.00</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/buy-qysmia-capsules-3-75-23mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Qysmia capsules online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/buy-qysmia-capsules-3-75-23mg-online/">Qysmia</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>250.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>590.94</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1.jpg 500w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/">Liquid Nicotine</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>35.99</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>73.96</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/buy-viagra-25mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Viagra 25mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1-.jpg 600w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/buy-viagra-25mg-online/">Viagra</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>245.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>895.00</bdi></span></span>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="highlight-product-wrap">
            <div class="highlight-image">
                <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1.jpg 500w" sizes="(max-width: 150px) 100vw, 150px"></a> </div>
            <div class="highlight-content-wrap">
                <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/">Liquid Nicotine</a>

                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>35.99</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>73.96</bdi></span></span>
            </div>
        </div>
    </div>
</div>
<!-- Owl -->

<!-- Hero-Banner -->
<section class="account-main">
    <div class='container'>
        <!-- Pills navs -->
        <ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="tab-login" data-mdb-toggle="pill" href="#pills-login" role="tab" aria-controls="pills-login" aria-selected="true">Login</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="tab-register" data-mdb-toggle="pill" href="#pills-register" role="tab" aria-controls="pills-register" aria-selected="false">Register</a>
            </li>
        </ul>
        <!-- Pills navs -->
<div class="row grid-margin" style="display:none;" id="del">
                            <div class="col-12">
                              <div class="alert alert-warning" role="alert">
                                  <strong id="msg">
                              </div>
                            </div>
                            <?php if(\Session::has('success')): ?>
                      <div class="alert alert-info">
                         <?php echo \Session::get('success'); ?> </ul>
                      </div>
                      <?php endif; ?>
                  </div> 
        <!-- Pills content -->
        <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
                <form id='loginuser' method="post">
                  <?php echo csrf_field(); ?>
                    <div class="text-center mb-3">
                        <p>Sign in with:</p>

                    </div>
                    <!-- Email input -->
                    <div class="form-outline mb-4">
                        <input type="email" id="loginName" class="form-control" name="email" />
                        <label class="form-label" for="loginName">Email or username</label>
                        <span class="eroor" id="emailError"></span>
                    </div>

                    <!-- Password input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="loginPassword" class="form-control" name="password" />
                        <label class="form-label" for="loginPassword">Password</label>
                        <span class="eroor" id="passwordError"></span>
                    </div>

                    <!-- 2 column grid layout -->
                    <div class="row mb-4">
                        <div class="col-md-6 d-flex justify-content-center">
                            <!-- Checkbox -->
                            <div class="form-check mb-3 mb-md-0">
                                <input class="form-check-input" type="checkbox" value="" id="loginCheck" checked />
                                <label class="form-check-label" for="loginCheck"> Remember me </label>
                            </div>
                        </div>

                        <div class="col-md-6 d-flex justify-content-center">
                            <!-- Simple link -->
                            <a href="#!">Forgot password?</a>
                        </div>
                    </div>
                    <!-- Submit button -->
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <button class="btn btn-primary mb-4" type="submit">Sign in</button>
                    </div>
                    <!-- Submit button -->
                    <!--<button type="submit" class="btn btn-primary btn-block mb-4">Sign in</button>-->

                    <!-- Register buttons -->
                    <div class="text-center">
                        <p>Not a member? <a href="#!">Register</a></p>
                    </div>
                </form>
            </div>
            <div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
                <form id="register" method="Post">
                <?php echo csrf_field(); ?>
                    <div class="text-center mb-3">
                        <p>Sign up with:</p>
                    </div>
                    <!-- Name input -->
                    <div class="form-outline mb-4">
                        <input type="text" id="registerName" class="form-control" name="name"/>
                        <label class="form-label" for="registerName">Name</label>
                        <span class="eroor" id="namess"></span>
                    </div>
                    <!-- Email input -->
                    <div class="form-outline mb-4">
                        <input type="email" id="registerEmail" class="form-control" name="email" />
                        <label class="form-label" for="registerEmail">Email</label>
                        <span class="eroor" id="emailss"></span>
                    </div>

                    <!-- Password input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="registerPassword" class="form-control" name="password" />
                        <label class="form-label" for="registerPassword">Password</label>
                        <span class="eroor" id="passwordss"></span>

                    </div>

                    <!-- Repeat Password input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="registerRepeatPassword" class="form-control" name="cpassword" />
                        <label class="form-label" for="registerRepeatPassword">Repeat password</label>
                        <span class="eroor" id="cpasswordss"></span>

                    </div>

                    <!-- Checkbox -->
                    

                    <!-- Submit button -->
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <button class="btn btn-primary mb-4" type="submit">Sign in</button>
                    </div>
                    <!--<button type="submit" class="btn btn-primary btn-block mb-3">Sign in</button>-->
                </form>
            </div>
        </div>
        <!-- Pills content -->
    </div>
</section>
<!-- Hero-Banner -->

<!--End header-->
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function(){
      $('#loginuser').on('submit', function (e) {
            e.preventDefault();
            var token = $(this).data("token");
               $.ajaxSetup({
                   headers: {
                       'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                   }
               });
            $.ajax({
              type: 'Post',
              url:"<?php echo e(url("loginuser")); ?>",
              data:new FormData(this),
              dataType:'JSON',
              contentType: false,
              cache: false,
              processData: false,
              success: function (data) {
               
                if(data.status==201){
                    $('#emailError').html(data.error.email);
                    $('#passwordError').html(data.error.password);
                    return false;
                 } if(data.status==203){
                  $('#del').show();
                  $("#del,msg").show().delay(5000).fadeOut();
                  $('#msg').html(data.wrongdetaisl);
                  return false;
                 }else {
                    $('#emailError').html("");
                    $('#passwordError').html("");
                     setTimeout(function(){
                       window.location.href = "<?php echo e(url('/')); ?>";
                     }, 1000);
                }
              }
             });
            });
    });


     $(function(){
      $('#register').on('submit', function (e) {
            e.preventDefault();
            var token = $(this).data("token");
               $.ajaxSetup({
                   headers: {
                       'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                   }
               });
            $.ajax({
              type: 'Post',
              url:"<?php echo e(url("register")); ?>",
              data:new FormData(this),
              dataType:'JSON',
              contentType: false,
              cache: false,
              processData: false,
              success: function (data) {
                if(data.status==201){
                    $('#emailss').html(data.error.email);
                    $('#namess').html(data.error.name);
                    $('#passwordss').html(data.error.password);
                    if(data.error.cpassword !==""){
                        $('#cpasswordss').html("THE REPEAT PASSWORD FIELD IS REQUIRED");
                    }
                 } if(data.status==203){
                     $('#emailss').html(data.email);
                 } else  {
                    $('#emailss').html("");
                    $('#namess').html("");
                    $('#passwordss').html("");
                    $('#cpasswordss').html("");
                  $('#del').show();
                  $("#del,msg").show().delay(5000).fadeOut();
                  $('#msg').html(data.success);
                     setTimeout(function(){
                       window.location.reload(1);
                     },1000);
                }
              }
             });
            });
    });
</script><?php /**PATH /Applications/MAMP/htdocs/Gazing/medstore/resources/views/web/account.blade.php ENDPATH**/ ?>