<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Hero section -->
    <section class="cart-main py-5">
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-info">
           <?php echo \Session::get('success'); ?> </ul>
        </div>
        <?php endif; ?>
        <div class="container">
            <h1>Shopping Cart</h1>

            <div class="shopping-cart">

            <div class="column-labels">
                <label class="product-image">Image</label>
                <label class="product-details">Product</label>
                <label class="product-price">Price</label>
                <label class="product-quantity">Quantity</label>
                <label class="product-removal">Remove</label>
                <label class="product-line-price">Total</label>
            </div>
            <?php
                $total = 0;
            ?>
           <?php if($cart->count()> 0): ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemcart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total += $itemcart->price*$itemcart->qty;
                ?>
                <div class="product">
                    <div class="product-image">
                        <img src="<?php echo e($itemcart->image ?? ''); ?>">
                    </div>
                    <div class="product-details">
                        <div class="product-title"><?php echo e($itemcart->title ?? ''); ?></div>

                    </div>
                    <div class="product-price"><?php echo e($itemcart->price ?? ''); ?></div>
                    <div class="product-quantity">
                        <input type="number" value="1" min="1">
                    </div>
                    <div class="product-removal">
                        <a href="<?php echo e(url('remove').'/'.$itemcart->id ?? ''); ?>" class="remove-product">
                            Remove
                        </a>
                    </div>
                    <div class="product-line-price"><?php echo e($itemcart->qty*$itemcart->price); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>



            <div class="totals">
                <div class="totals-item">
                 <label>Subtotal</label>
                <div class="totals-value" id="cart-subtotal"><?php echo e($total ?? ''); ?></div>
                </div>
                <div class="totals-item">
                    <?php
                        $new_width = (5 / 100) * $total;
                    ?>
                <label>Tax (5%)</label>
                <div class="totals-value" id="cart-tax"><?php echo e($total-$new_width ?? ''); ?></div>
                </div>
                <div class="totals-item">
                <label>Shipping</label>
                <div class="totals-value" id="cart-shipping">15</div>
                </div>
                <div class="totals-item totals-item-total">
                <label>Grand Total</label>
                <div class="totals-value" id="cart-total"><?php echo e($total+15+$new_width); ?></div>
                </div>
            </div>
                <a href="<?php echo e(url('checkout')); ?>" class="checkout">Proceed to checkout</a>
            </div>
        </div>
    </section>
    <!-- Hero section -->

    <?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\medstor\resources\views/web/cart.blade.php ENDPATH**/ ?>