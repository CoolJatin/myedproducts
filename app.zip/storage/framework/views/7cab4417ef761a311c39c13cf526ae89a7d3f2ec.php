<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
<div class="main-panel">
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                 <button style="float:right" type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">Add Gallery</button>
                    <h4 class="card-title">Gallery Table</h4><hr>
                    <div class="table-responsive">
                   <div class="row grid-margin" style="display:none;" id="del">
                            <div class="col-12">
                              <div class="alert alert-warning" role="alert">
                                  <strong id="msg">
                              </div>
                            </div>
                            <?php if(\Session::has('success')): ?>
                      <div class="alert alert-info">
                         <?php echo \Session::get('success'); ?> </ul>
                      </div>
                      <?php endif; ?>
                  </div> 
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th>Sr No.</th>
                                <th>Product Name</th>
                                <th>Image</th>
                                <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($image->count()> 0): ?>
                            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$i); ?></td>
                                    <?php
                                        $gallery = DB::table('product')->where('id',$items->productid)->first();
                                    ?>
                                        <td><?php echo e($gallery->title ?? ''); ?></td>
                                        <td class="py-1"><img src="<?php echo e(asset('public/admin/images').'/'.$items->image ?? ''); ?>" alt="image" /></td>

                                        
                                        <td><button onclick="MyEditFunction(<?php echo e($items->id); ?>)" class="btn btn-success btn-sm">Edit</button> || <a onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm" href="<?php echo e(url('admin/removegallery').'/'.$items->id ?? ''); ?>">Delete</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                           
                        </table>
                    </div>
                    
                </div>
                 
            </div>
            
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="#" id="SaveGallery" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="id" name="id">  
            <input type="hidden" name="proid" value="<?php echo e($proid ?? ''); ?>">             
                <div class="form-group">
                        <label for="">Image</label>
                    <input type="file" name="image" class="form-control">
                    <span style="color:red;" id="thumbnail"></span>
                </div>
                <input type="submit" name="submit" value="Submit" class="btn btn-primary">
         </form>
        </div>
      </div>
    </div>
  </div>
<script>
    $(function(){
          $('#SaveGallery').on('submit', function (e) {
            e.preventDefault();
            var token = $(this).data("token");
               $.ajaxSetup({
                   headers: {
                       'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                   }
               });
            $.ajax({
              type: 'Post',
              url:"<?php echo e(url('admin/updategallery')); ?>",
              data:new FormData(this),
              dataType:'JSON',
              contentType: false,
              cache: false,
              processData: false,
              success: function (data) {
                if(data.status==201){
                    $('#thumbnail').html(data.error.image);
                    return false;
                 }if(data.status==202){
                    $('#slug').html(data.error);
                    return false;
                 }else {
                  $('#del').show();
                  $("#del,msg").show().delay(5000).fadeOut();
                  $('#msg').html(data.success);
                  $('#myModal').modal('hide');
                     setTimeout(function(){
                       window.location.reload(1);
                    }, 1000);
                }
              }
             });
            });
          });

  function MyEditFunction(id){
     $.ajax({
        type:"get",
        url:"<?php echo e(url('admin/editgallery')); ?>/"+id,
        success:function(data){
             if(data.status==200){
                $('#id').val(data.sussess.id);
                $('#myModal').modal('show');
            } else {
              alert('data not Found!');
            }
        }
     });
  }

</script>

<?php /**PATH /home4/gazingdev/public_html/medstore/dynamic/resources/views/admin/product/gallery.blade.php ENDPATH**/ ?>