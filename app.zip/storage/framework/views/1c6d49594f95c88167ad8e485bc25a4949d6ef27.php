<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
<div class="main-panel">
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                 <a style="float:right" href="<?php echo e(url('admin/createproduct')); ?>" class="btn btn-primary btn-sm">Add Product</a>
                    <h4 class="card-title">Product Table</h4><hr>
                    <div class="table-responsive">
                   <div class="row grid-margin" style="display:none;" id="del">
                            <div class="col-12">
                              <div class="alert alert-warning" role="alert">
                                  <strong id="msg">
                              </div>
                            </div>
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-info">
                                    <?php echo \Session::get('success'); ?> </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Sr No.</th>
                                    <th>Orderid</th>
                                    <th>Image</th>
                                    <th>Title</th>

                                    <th>Price</th>
                                    <th>Price</th>

                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                        <?php if($order->count()> 0): ?>
                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$i); ?></td>
                                    <td><?php echo e($items->orderid ?? ''); ?></td>

                                    <td class="py-1"><img src="<?php echo e($items->image ?? ''); ?>" alt="image" /></td>
                                        <td><?php echo e($items->title ?? ''); ?></td>

                                        <td><?php echo e($items->price ?? ''); ?></td>
                                        <td><?php echo e($items->datetime ?? ''); ?></td>
                                            <?php if($items->status==1): ?>
                                                <td><a class="btn btn-success btn-sm" href="#">Active</a></td>
                                            <?php else: ?>
                                                <td><a class="btn btn-danger btn-sm" href="#">New</a></td>
                                            <?php endif; ?>
                                           <td>
                                               <a href="">Print</a>
                                           </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<?php /**PATH C:\xampp\htdocs\medstor\resources\views/admin/order/order.blade.php ENDPATH**/ ?>