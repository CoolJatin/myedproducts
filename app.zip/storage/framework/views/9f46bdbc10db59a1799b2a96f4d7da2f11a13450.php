<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
<div class="main-panel">
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                 <a style="float:right" href="<?php echo e(url('admin/createproduct')); ?>" class="btn btn-primary btn-sm">Add Product</a>
                    <h4 class="card-title">Product Table</h4><hr>
                    <div class="table-responsive">
                   <div class="row grid-margin" style="display:none;" id="del">
                            <div class="col-12">
                              <div class="alert alert-warning" role="alert">
                                  <strong id="msg">
                              </div>
                            </div>
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-info">
                                    <?php echo \Session::get('success'); ?> </ul>
                                </div>
                            <?php endif; ?>
                        </div> 
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Sr No.</th>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th>Mrp Price</th>
                                    <th>Price</th>
                                    <th>Edit Image</th>
                                    <th>Add Multi Price</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                        <?php if($product->count()> 0): ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$i); ?></td>
                                    <td class="py-1"><img src="<?php echo e(asset('public/admin/images').'/'.$items->image ?? ''); ?>" alt="image" /></td>
                                        <td><?php echo e($items->title ?? ''); ?></td>
                                        <td><?php echo e($items->mrp_price ?? ''); ?></td> 
                                        <td><?php echo e($items->price ?? ''); ?></td> 
                                        <td><a href="<?php echo e(url('admin/editimage').'/'.$items->id ?? ''); ?>" class="btn btn-success btn-sm">Edit</a></td>
                                        <td><a href="<?php echo e(url("admin/addmultiprice").'/'.$items->id ?? ''); ?>" class="btn btn-info btn-sm">Add Price</a></td>
                                            <?php if($items->status==1): ?>
                                                <td><a class="btn btn-success btn-sm" href="#">Active</a></td>
                                            <?php else: ?>
                                                <td><a class="btn btn-danger btn-sm" href="#">Hold</a></td>
                                            <?php endif; ?>
                                            <td>
                                                <div class="dropdown">
                                                <button type="button" class="btn btn-warning btn-sm dropdown-toggle" id="dropdownMenuIconButton7" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                  <i class="ti-user"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuIconButton7">
                                                <a href="<?php echo e(url('admin/editproduct').'/'.$items->id ?? ''); ?>" class="btn btn-success btn-sm">Edit</a>
                                                <a onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm" href="<?php echo e(url('admin/removeproduct').'/'.$items->id ?? ''); ?>">Delete</a>
                                                 
                                                </div>
                                              </div>
                                            </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody> 
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<?php /**PATH /Applications/MAMP/htdocs/Gazing/medstore/resources/views/admin/product/product.blade.php ENDPATH**/ ?>