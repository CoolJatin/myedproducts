<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <!-- Owl -->
      <div class="owl-carousel owl-theme py-3">
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/buy-ritalin-20mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Ritalin 20mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/Ritalin_LA_藥罐外觀_20160618-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/buy-ritalin-20mg-online/">Ritalin 20mg</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>180.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>740.00</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/oxycodone-m523-10325/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-150x150.png" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-150x150.png 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/226ad24b5d-100x100.png 100w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/oxycodone-m523-10325/">Oxycodone m523 10325</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>320.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>720.00</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/xanax/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Xanax 2mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/xanax-bas-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/xanax/">Xanax 2mg</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>600.00</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/buy-qysmia-capsules-3-75-23mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Qysmia capsules online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/01/Qsymia_bottle-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/buy-qysmia-capsules-3-75-23mg-online/">Qysmia</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>250.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>590.94</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1.jpg 500w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/">Liquid Nicotine</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>35.99</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>73.96</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/buy-viagra-25mg-online/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="Buy Viagra 25mg online" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1--100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/simple-online-pharmacy-viagra-for-erections-generic-sildenafil-1621335473Viagra-1-.jpg 600w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/buy-viagra-25mg-online/">Viagra</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>245.00</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>895.00</bdi></span></span>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="highlight-product-wrap">
               <div class="highlight-image">
                  <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="150" height="150" src="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="" loading="lazy" srcset="https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-150x150.jpg 150w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-300x300.jpg 300w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1-100x100.jpg 100w, https://trinitymedstore.com/wp-content/uploads/2021/11/Pure-Nicotine-500x500-1.jpg 500w" sizes="(max-width: 150px) 100vw, 150px"></a>                                
               </div>
               <div class="highlight-content-wrap">
                  <a href="https://trinitymedstore.com/index.php/product/liquid-nicotine/">Liquid Nicotine</a>
                  <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>35.99</bdi></span> – <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>73.96</bdi></span></span>
               </div>
            </div>
         </div>
      </div>
      <!-- Owl -->
      <!-- Hero-Banner -->
      <div class="hero-banner">
         <div class="container">
            <div class="row">
               <div class="col mx-auto">
                  <h1 class="text-white text-center"><span>WELCOME TO TRINITY MEDSTORE</span>
                     20% Off For all Orders with Bitcoin
                  </h1>
               </div>
            </div>
            <button type="button" class="btn btn-lg text-white btn-success">SHOP NOW<i class="ml-5 fa fa-shopping-cart mr-5"></i></button>
         </div>
      </div>
      <!-- Hero-Banner -->
      <div class="hero-bottom">
         <div class="container">
            <div class="row">
               <div class="col text-center">
                  <div class="hero-child hero-first py-md-5">
                     <i class="fas fa-truck mb-2 text-white"></i>
                     <h5 class="text-white"><span>FAST WORLDWIDE</span> DELIVERY</h5>
                  </div>
               </div>
               <div class="col text-center">
                  <div class="hero-child py-md-5">
                     <i class="fas fa-rocket mb-2 text-white"></i>
                     <h5 class="text-white"><span>3 DAYS RETURN</span> POLICY</h5>
                  </div>
               </div>
               <div class="col text-center">
                  <div class="hero-child py-md-5">
                     <i class="fas fa-headphones mb-2 text-white"></i> 
                     <h5 class="text-white"><span>24/7 CUSTOMER</span> SERVICE</h5>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="description-section py-4">
         <div class="container">
            <div class="row">
               <div class="col-md-10 mx-auto py-4">
                  <div class="head-1">
                     <h2 class="text-center">LIVERY 3 DAYS RETURN POLICY 24/7 CUSTOMER SERVICE
                        Buy Valium Online Without Prescription 
                     </h2>
                  </div>
               </div>
            </div>
            <p class="text-center mb-4">Valium (diazepam) is a benzodiazepine (ben-zoe-dye-AZE-eh-peens). Diazepam affects chemicals in the brain that may be unbalanced in people with anxiety. Buy Valium Online Without Prescription. Valium is used to treat anxiety disorders, alcohol withdrawal symptoms, or muscle spasms. Valium is sometimes used with other medications to treat seizures. Buy Valium Online Without Prescription</p>
         </div>
      </div>
      <div class="description-section-2 py-4">
         <div class="container">
            <div class="row">
               <div class="col py-4">
                  <div class="head-2">
                     <h2 class="text-center mb-4">Best place to Buy Valium online | Purchase valium online</h2>
                     <p>You should not use Valium if you are allergic to diazepam or similar medicines (Klonopin, Xanax, and others), or if you have myasthenia gravis, severe liver disease, narrow-angle glaucoma, a severe breathing problem, or sleep apnea. MISUSE OF THIS MEDICINE CAN CAUSE ADDICTION, OVERDOSE, OR DEATH, especially in a child or other person using the medicine without a prescription. Purchase valium online. Fatal side effects can occur if you use Valium with opioid medicine, alcohol, or other drugs that cause drowsiness or slow your breathing. Do not give this medication to a child younger than 6 months old. Before taking this medicine You should not use Valium if you are allergic to diazepam or similar drugs (Klonopin, Xanax, and others), or if you have:</p>
                     <ul class="list-parent">
                        <li class="list-child" style="list-style: disc;">myasthenia gravis (a muscle weakness disorder);</li>
                        <li class="list-child" style="list-style: disc;">severe liver disease;</li>
                        <li class="list-child" style="list-style: disc;">a severe breathing problem;</li>
                        <li class="list-child" style="list-style: disc;">sleep apnea (breathing stops during sleep); or</li>
                        <li class="list-child" style="list-style: disc;">alcoholism, or addiction to drugs similar to diazepam.</li>
                        <li class="list-child" style="list-style: disc;">To make sure Valium is safe for you, tell your doctor if you have ever had:</li>
                        <li class="list-child" style="list-style: disc;">glaucoma;</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section class="li-section py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-head text-center mx-auto mb-4">
                     <h2>How should I take Valium? | Order Valium online </h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                  <ul>
                     <li style="list-style: disc;" class="mb-3">Take Valium exactly as prescribed by your doctor. Follow all directions on your prescription label. Your doctor may occasionally change your dose. Do not take this medicine in larger or smaller amounts or for longer than recommended. 
                        Buy Valium Online Without Prescription 
                     </li>
                     <li style="list-style: disc;" class="mb-3">Diazepam may be habit-forming. Misuse of habit-forming medicine can cause addiction, overdose,
                        or death. Selling or giving away Valium is against the law.
                     </li>
                     <li style="list-style: disc;" class="mb-3">Measure liquid medicine with the dosing syringe provided, or with a special dose-measuring spoon or medicine cup.
                        If you do not have a dose-measuring device, ask your pharmacist for one.
                     </li>
                     <li style="list-style: disc;" class="mb-3">
                        Valium should be used for only a short time. Do not take this medicine for longer than 4 months without your doctor’s advice. 
                        Order Valium online.
                     </li>
                  </ul>
               </div>
               <div class="col-md-6">
                  <ul>
                     <li style="list-style: disc;" class="mb-3">Do not stop using Valium suddenly, or you could have increased seizures or unpleasant
                        withdrawal symptoms. Ask your doctor how to safely stop using this medicine.
                     </li>
                     <li style="list-style: disc;" class="mb-3">Call your doctor at once if you feel that this medicine is not working as well as usual,
                        or if you think you need to use more than usual.
                     </li>
                     <li style="list-style: disc;" class="mb-3">Store at room temperature away from moisture, heat, and light. Keep track of your medicine. Diazepam is a drug of abuse and you should
                        be aware if anyone is using your medicine improperly or without a prescription.
                     </li>
                     <li style="list-style: disc;" class="mb-3">
                        Do not keep leftover diazepam. Just one dose can cause death in someone using Valium accidentally or improperly. Ask your pharmacist where to locate a drug take-back disposal program. 
                        If there is no take-back program, flush the unused medicine down the toilet. Order Valium online 
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
      
      <section class="bank-transfer py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-head text-center col-md-10 mx-auto">
                     <h2>WE ACCEPT BANK TRANSFERS</h2>
                     <p>*By Selecting Bank Transfer, Please make sure your order is above $1000. We do not accept Credit card payments below this amount. You will be making payments from your bank into our bank account manually. 
                        When you place your order, we will contact you on how to complete the payment.*
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </section>
    
      <main class="main">
         <!--End banners-->
         <section class="product-tabs section-padding position-relative py-5">
            <div class="container">
               <div class="section-title style-2 wow animate__animated animate__fadeIn">
                  <h3>FEATURE Products</h3>
               </div>
               <!--End nav-tabs-->
               <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="tab-one" role="tabpanel" aria-labelledby="tab-one">
                     <div class="row product-grid-4">
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".1s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-1-1.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-1-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Compare" class="action-btn" href="shop-compare.html"><i class="fa fa-random"></i></a>
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="hot">Hot</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Liquid Nicotine</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$35.99 – $73.96</span>
                                       <!-- <span class="old-price">$32.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class="fa-solid fa fa-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-2-1.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-2-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="sale">Sale</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Viagra</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 80%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (3.5)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$245.00 – $895.00</span>
                                       <!-- <span class="old-price">$55.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class='fa fa-shopping-cart mr-5'></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".3s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-3-1.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-3-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="new">New</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Tramadol</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 85%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$170.00 – $620.00</span>
                                       <!-- <span class="old-price">$52.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class="fa fa-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".5s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/green.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-5-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="best">-14%</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Green Xanax</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$340.00 – $600.00</span>
                                       <!-- <span class="old-price">$25.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class="fa fa-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap wow animate__animated animate__fadeIn" data-wow-delay=".1s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/oxy-man-300x300.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-6-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="best">-14%</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Oxycontin</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$180.00 – $575.00</span>
                                       <!-- <span class="old-price">$55.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class='fa fa-shopping-cart mr-5'></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap wow animate__animated animate__fadeIn" data-wow-delay=".1s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-6-1.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-6-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="best">-14%</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Adderall 30mg</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$180.00 – $650.00</span>
                                       <!-- <span class="old-price">$55.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class='fa fa-shopping-cart mr-5'></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end product card -->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap wow animate__animated animate__fadeIn" data-wow-delay=".2s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-7-1.jpg" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-7-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="best">-14%</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Ritalin 20mg</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$180.00 – $740.00</span>
                                       <!-- <span class="old-price">$33.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class="fa fa-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->
                        <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                           <div class="product-cart-wrap wow animate__animated animate__fadeIn" data-wow-delay=".3s">
                              <div class="product-img-action-wrap mb-4 ">
                                 <div class="product-img product-img-zoom">
                                    <a href="shop-product-right.html">
                                       <img class="default-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-8-1.png" alt="" />
                                       <!-- <img class="hover-img" src="<?php echo e(asset('public/')); ?>/assets/imgs/product-8-2.jpg" alt="" /> -->
                                    </a>
                                 </div>
                                 <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fa fa-eye"></i></a>
                                 </div>
                                 <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="best">-14%</span>
                                 </div>
                              </div>
                              <div class="product-content-wrap">
                                 <h2><a href="shop-product-right.html">Oxycodone m523 10325</a></h2>
                                 <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                       <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                 </div>
                                 <div class="product-card-bottom">
                                    <div class="product-price">
                                       <span>$320.00 – $720.00</span>
                                       <!-- <span class="old-price">$37.8</span> -->
                                    </div>
                                    <div class="add-cart">
                                       <a class="add" href="cart.html"><i class="fa fa-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--end product card-->                                
                     </div>
                     <!--End product-grid-4-->
                  </div>
               </div>
               <!--End tab-content-->
            </div>
         </section>
         <!-- About Us -->
         <section class="about-us">
            <div class="container">
               <div class="row">
                  <div class="col-md-6 about-col">
                     <figure><img src="<?php echo e(asset('public/')); ?>/assets/imgs/Laboratory-Technician-2000x1200-1-1024x614.jpg" alt=""></figure>
                  </div>
                  <div class="col-md-6">
                     <h2 class="mb-20">About us </h2>
                     <p class="mb-15">With all said above and couple with the testimonies given on each product you fine in our store. 
                        We stand the best chance for you to buy valium online, best place to buy heroin online, buy opana online
                        without prescription. How ever you can also buy all painkillers online, order fentanyl patches online safe 
                        and legit. When shopping with us, you can rest guaranteed that your request will be bundled enough and 
                        attentively.
                     </p>
                     <p>That is the manner by which we ensure you get the most noteworthy nature of any exploration 
                        compound you need. Investigate the substances accessible in our index Even on the off chance that you are
                        going to inquire about heroin (otherwise called diamorphine), we have you secured with the most perfect
                        heroin available to be purchased.
                     </p>
                  </div>
               </div>
            </div>
         </section>
         <!-- About Us -->
         <!--Products Tabs-->
         <section class="section-padding pb-5">
            <div class="container">
               <div class="section-title wow animate__animated animate__fadeIn">
                  <h3 class="">Daily Best Sells</h3>
               </div>
               <div class="row">
                  <div class="col-lg-3 d-none d-lg-flex wow animate__animated animate__fadeIn">
                     <div class="banner-img style-2">
                        <div class="banner-text">
                           <h2 class="mb-100 text-white">Bring Best Sells into your home</h2>
                           <a href="shop-grid-right.html" class="btn btn-xs text-white btn-success">Shop Now <i class="fa fa-angle-right ml-5"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-9 col-md-12 wow animate__animated animate__fadeIn" data-wow-delay=".4s">
                     <div class="tab-content" id="myTabContent-1">
                        <div class="tab-pane fade show active" id="tab-one-1" role="tabpanel" aria-labelledby="tab-one-1">
                           <div class="carausel-4-columns-cover arrow-center position-relative">
                              <!-- <div class="slider-arrow slider-arrow-2 carausel-4-columns-arrow" id="carausel-4-columns-arrows"><span class="slider-btn slider-prev slick-arrow" style=""><i class="fa fa-angle-left"></i></span>
                                 <span class="slider-btn slider-next slick-arrow" style=""><i class="fa fa-angle-right"></i></span>
                                 </div> -->
                              <div class="carausel-4-columns carausel-arrow-center" id="carausel-4-columns">
                                 <div class="product-cart-wrap">
                                    <div class="product-img-action-wrap mb-4 ">
                                       <div class="product-img product-img-zoom">
                                          <a href="shop-product-right.html">
                                             <img class="default-img" src="assets/imgs/spilled-pills-copy-copy-300x300.png" alt="" />
                                             <!-- <img class="hover-img" src="assets/imgs/shop/product-1-2.jpg" alt="" /> -->
                                          </a>
                                       </div>
                                       <div class="product-action-1">
                                          <a aria-label="Quick view" class="action-btn small hover-up" data-bs-toggle="modal" data-bs-target="#quickViewModal"> <i class="fa fa-eye"></i></a>
                                       </div>
                                       <div class="product-badges product-badges-position product-badges-mrg">
                                          <span class="hot">Save 15%</span>
                                       </div>
                                    </div>
                                    <div class="product-content-wrap">
                                       <h2><a href="shop-product-right.html">OPIODS </a></h2>
                                    </div>
                                 </div>
                                 <!--End product Wrap-->
                                 <div class="product-cart-wrap">
                                    <div class="product-img-action-wrap mb-4 ">
                                       <div class="product-img product-img-zoom">
                                          <a href="shop-product-right.html">
                                             <img class="default-img" src="assets/imgs/buy-alpha-php-chemsresearch-com-research-chemicals-free-300x300.png" alt="" />
                                             <!-- <img class="hover-img" src="assets/imgs/shop/product-5-2.jpg" alt="" /> -->
                                          </a>
                                       </div>
                                       <div class="product-action-1">
                                          <a aria-label="Quick view" class="action-btn small hover-up" data-bs-toggle="modal" data-bs-target="#quickViewModal"> <i class="fa fa-eye"></i></a>
                                       </div>
                                    </div>
                                    <div class="product-content-wrap">
                                       <h2><a href="shop-product-right.html">RESEARCH CHEMICALS </a></h2>
                                    </div>
                                 </div>
                                 <!--End product Wrap-->
                                 <div class="product-cart-wrap">
                                    <div class="product-img-action-wrap mb-4 ">
                                       <div class="product-img product-img-zoom">
                                          <a href="shop-product-right.html">
                                             <img class="default-img" src="assets/imgs/Pill-Bottle-and-Prescription-Pad-300x300.png" alt="" />
                                             <!-- <img class="hover-img" src="assets/imgs/shop/product-2-2.jpg" alt="" /> -->
                                          </a>
                                       </div>
                                       <div class="product-action-1">
                                          <a aria-label="Quick view" class="action-btn small hover-up" data-bs-toggle="modal" data-bs-target="#quickViewModal"> <i class="fa fa-eye"></i></a>
                                       </div>
                                       <div class="product-badges product-badges-position product-badges-mrg">
                                          <span class="sale">Sale</span>
                                       </div>
                                    </div>
                                    <div class="product-content-wrap">
                                       <h2><a href="shop-product-right.html"> RX Drugs </a></h2>
                                    </div>
                                 </div>
                                 <!--End product Wrap-->
                                 <div class="product-cart-wrap">
                                    <div class="product-img-action-wrap mb-4 ">
                                       <div class="product-img product-img-zoom">
                                          <a href="shop-product-right.html">
                                             <img class="default-img" src="assets/imgs/images-5.jpg" alt="" />
                                             <!-- <img class="hover-img" src="assets/imgs/shop/product-3-2.jpg" alt="" /> -->
                                          </a>
                                       </div>
                                       <div class="product-action-1">
                                          <a aria-label="Quick view" class="action-btn small hover-up" data-bs-toggle="modal" data-bs-target="#quickViewModal"> <i class="fa fa-eye"></i></a>
                                       </div>
                                       <div class="product-badges product-badges-position product-badges-mrg">
                                          <span class="best">Best sale</span>
                                       </div>
                                    </div>
                                    <div class="product-content-wrap">
                                       <h2><a href="shop-product-right.html">XTC Pills </a></h2>
                                    </div>
                                 </div>
                                 <!--End product Wrap-->
                                 <div class="product-cart-wrap">
                                    <div class="product-img-action-wrap mb-4 ">
                                       <div class="product-img product-img-zoom">
                                          <a href="shop-product-right.html">
                                             <img class="default-img" src="assets/imgs/woocommerce-placeholder.png" alt="" />
                                             <!-- <img class="hover-img" src="assets/imgs/shop/product-4-2.jpg" alt="" /> -->
                                          </a>
                                       </div>
                                       <div class="product-action-1">
                                          <a aria-label="Quick view" class="action-btn small hover-up" data-bs-toggle="modal" data-bs-target="#quickViewModal"> <i class="fa fa-eye"></i></a>
                                       </div>
                                       <div class="product-badges product-badges-position product-badges-mrg">
                                          <span class="hot">Save 15%</span>
                                       </div>
                                    </div>
                                    <div class="product-content-wrap">
                                       <h2><a href="shop-product-right.html"> Nicotine </a></h2>
                                    </div>
                                 </div>
                                 <!--End product Wrap-->
                              </div>
                           </div>
                        </div>
                     </div>
                     <!--End tab-content-->
                  </div>
                  <!--End Col-lg-9-->
               </div>
            </div>
         </section>
         <!--End 4 columns-->
      </main>
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      <?php /**PATH /Applications/MAMP/htdocs/Gazing/medstore/resources/views/web/index.blade.php ENDPATH**/ ?>