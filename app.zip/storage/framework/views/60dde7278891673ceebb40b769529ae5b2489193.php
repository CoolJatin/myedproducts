<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                 <?php if(\Session::has('success')): ?>
                        <div class="alert alert-info">
                            <?php echo \Session::get('success'); ?> </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h4 class="card-title">Create About</h4>
                        <form class="form-sample" action="<?php echo e(url('admin/addproduct')); ?>" method="Post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($data->id ?? ''); ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Title</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="title" value="<?php echo e($data->title ?? ''); ?>" />
                                             <?php if($errors->has('title')): ?>
                                                <span class="error"><?php echo e($errors->first('title')); ?></span>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">SKU</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="sku" value="<?php echo e($data->sku ?? ''); ?>" />
                                            <?php if($errors->has('sku')): ?>
                                                <span class="error"><?php echo e($errors->first('sku')); ?></span>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Category</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="category">
                                                <option value="">Select Category</option>
                                            <?php if($category->count()> 0): ?>
                                               <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option value="<?php echo e($items->id ?? ''); ?>" <?php if ($items->id == @$data->catid) echo ' selected="selected"'; ?>><?php echo e($items->name ?? ''); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('category')): ?>
                                                <span class="error"><?php echo e($errors->first('category')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">MRP PRICE</label>
                                        <div class="col-sm-9">
                                            <input type="number" class="form-control" name="mrp" value="<?php echo e($data->mrp_price ?? ''); ?>" />
                                            <?php if($errors->has('mrp')): ?>
                                            <span class="error"><?php echo e($errors->first('mrp')); ?></span>
                                        <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Sale Price</label>
                                        <div class="col-sm-9">
                                            <input type="number" class="form-control" name="price" value="<?php echo e($data->price ?? ''); ?>" />
                                             <?php if($errors->has('price')): ?>
                                                <span class="error"><?php echo e($errors->first('price')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                  <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Sataus</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="status">
                                                <option value="">Select Status</option>
                                                <option value="1" <?php if (1 == @$data->status ?? '') echo ' selected="selected"'; ?>>Enable</option>
                                                <option value="0" <?php if (0 == @$data->status ?? '') echo ' selected="selected"'; ?>>Disable</option>
                                            </select>
                                            <?php if($errors->has('status')): ?>
                                                <span class="error"><?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                             <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Slug</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="slug" value="<?php echo e($data->slug ?? ''); ?>" />
                                             <?php if($errors->has('slug')): ?>
                                                <span class="error"><?php echo e($errors->first('slug')); ?></span>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Image</label>
                                        <div class="col-sm-9">
                                            <input type="file" class="form-control" name="image"/>
                                             <?php if($errors->has('image')): ?>
                                                <span class="error"><?php echo e($errors->first('image')); ?></span>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label class="col-sm-1 col-form-label">Short Description</label>
                                        <div class="col-sm-11">
                                            <textarea name="shortdescription" id="editor1"><?php echo e($data->shortdescription ?? ''); ?></textarea>
                                            <?php if($errors->has('shortdescription')): ?>
                                                <span class="error">The short description field is required</span>

                                            <?php endif; ?>
                                        </div>
                                        <script>
                                           CKEDITOR.replace( 'editor1' );
                                        </script>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label class="col-sm-1 col-form-label">Description</label>
                                        <div class="col-sm-11">
                                            <textarea name="description" id="editor2"><?php echo e($data->description ?? ''); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="error"><?php echo e($errors->first('description')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <script>
                                       CKEDITOR.replace( 'editor2' );
                                    </script>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label class="col-sm-1 col-form-label">More Description</label>
                                        <div class="col-sm-11">
                                            <textarea name="moredescription" id="editor3"><?php echo e($data->more_infomation ?? ''); ?></textarea>
                                            <script>
                                                CKEDITOR.replace( 'editor3' );
                                            </script>
                                             <?php if($errors->has('moredescription')): ?>
                                                <span class="error">The more description field is required.</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            </div>

                        <?php if(empty($data)): ?>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">Select Multi Image</label>
                                    <div class="col-sm-11">
                                       <input type="file" name="multiimage[]" class="form-control" multiple>
                                        <?php if($errors->has('multiimage')): ?>
                                            <span class="error"><?php echo e($errors->first('multiimage')); ?></span>
                                        <?php endif; ?>
                                    </div>
                            </div>
                            </div>
                        <?php endif; ?>
                        <div class="col-md-12">
                            <div class="form-group row">
                                <label class="form-check-label">BEST SELLS</label>
                                <input class="form-check-input" type="checkbox" id="check1" name="type" value="1" <?php if(@$data->type==1): ?><?php echo e("checked"); ?><?php else: ?><?php echo e(""); ?><?php endif; ?>>

                        </div>
                        </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <div class="col-sm-11">
                                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home4/gazingdev/public_html/medstore/dynamic/resources/views/admin/product/createproduct.blade.php ENDPATH**/ ?>