<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <?php if(\Session::has('success')): ?>
                    <div class="alert alert-info">
                        <?php echo \Session::get('success'); ?> </ul>
                    </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h4 class="card-title">Create Product</h4>
                        <form class="form-sample" action="<?php echo e(url('admin/createabout')); ?>" method="Post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($data->id ?? ''); ?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label class="col-sm-1 col-form-label">Title</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="title" value="<?php echo e($data->title ?? ''); ?>" />
                                            <?php if($errors->has('title')): ?>
                                            <span class="error"><?php echo e($errors->first('title')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-10">
                                        <div class="form-group row">
                                            <label class="col-sm-1 col-form-label">Description</label>
                                            <div class="col-sm-11">
                                                <textarea name="description" id="editor2"><?php echo e($data->description ?? ''); ?></textarea>
                                                <?php if($errors->has('description')): ?>
                                                <span class="error"><?php echo e($errors->first('description')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <script>
                                            CKEDITOR.replace('editor2');

                                        </script>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label class="col-sm-1 col-form-label">Image</label>
                                        <div class="col-sm-10">
                                            <input type="file" name="image" class="form-control">
                                            <?php if($errors->has('image')): ?>
                                            <span class="error"><?php echo e($errors->first('image')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-11">
                                                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\medstor\resources\views/admin/about/about.blade.php ENDPATH**/ ?>