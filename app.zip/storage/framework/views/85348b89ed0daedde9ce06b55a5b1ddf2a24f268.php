<!-- Footer -->
      <footer>
         <div class="footer-top">
            <div class="container">
               <div class="row">
                  <div class="row">
                     <div class="col-lg-4 col-sm-6">
                        <div class="address">
                           <h3 class="text-success">TRINITY MedStore</h3>
                           <p>With all said above and couple with the testimonies given on each product you fine in our store.</p>
                        </div>
                     </div>
                     <div class="col-lg-2 col-sm-6 footer-menus">
                        <h4 class="text-success">Product categories</h4>
                        <ul>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">Benzodiazepine</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">Nicotine</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">OPIODS</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">RESEARCH CHEMICALS</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">RX Drugs</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">Sex Pills</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">Uncategorized</a></li>
                           <li><i class="fas fa-check" aria-hidden="true"></i> <a href="#">XTC Pills</a></li>
                        </ul>
                     </div>
                     <div class="col-lg-3 footer-menus col-sm-6">
                        <h4 class="text-success">Best selling</h4>
                        <ul>
                           <li><a href="#"><span class="footer-span">Buy 3,4-DMMC online</span> $126.50 – $3,450.00</a></li>
                           <li><a href="#"><span class="footer-span">2-FMA</span>$103.50 – $1,955.00</a></li>
                           <li><a href="#"><span class="footer-span">2-AIMP</span>$126.50 – $3,450.00</a></li>
                           <li><a href="#"><span class="footer-span">2-AI</span>$126.50 – $3,450.00</a></li>
                           <li><a href="#"><span class="footer-span">4-MEO-PCP</span>$138.00 – $2,300.00</a></li>
                        </ul>
                     </div>
                     <div class="col-lg-3 newsletter col-sm-6">
                        <div class="address">
                           <h4 class="text-success">CONTACT US</h4>
                           <p><strong>Phone:</strong> +1 (716) 266-6513</p>
                           <p><strong>Email:</strong> contact@trinitymedstore.com</p>
                           <p><strong>Address:</strong> Apple Valley, San Bernardino CA 92307</p>
                        </div>
                        <div class="social-links mt-3">
                           <a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                           <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                           <a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
                           <a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                           <a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <div class="footer-bottom">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <p class="text-center mb-2 text-white">Copyrights Ⓒ2021 TRINITY MEDSTORE LLC all rights reserved.</p>
                  <p class="text-center mb-0 text-white">Created by <a href="https://www.gazingtechnosoft.com/" class="text-success">gazingtechnosoft</a></p>
               </div>
            </div>
         </div>
      </div>
      <!-- Footer -->
      <!-- Preloader Start -->
      <div id="preloader-active">
         <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
               <div class="text-center">
                  <img src="assets/imgs/loading.gif" alt="" />
               </div>
            </div>
         </div>
      </div>
      <!-- Vendor JS-->
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/modernizr-3.6.0.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery-3.6.0.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery-migrate-3.3.0.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/bootstrap.bundle.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/slick.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery.syotimer.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/owl.carousel.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/wow.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery-ui.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/perfect-scrollbar.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/magnific-popup.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/select2.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/waypoints.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/counterup.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery.countdown.min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/images-loaded.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/isotope.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/scrollup.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery.vticker-min.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery.theia.sticky.js"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/jquery.elevatezoom.js"></script>
      <script src="https://kit.fontawesome.com/95e754a97c.js" crossorigin="anonymous"></script>
      <!-- Template  JS -->
      <script src="<?php echo e(asset('public/')); ?>/assets/js/main.js?v=4.1"></script>
      <script src="<?php echo e(asset('public/')); ?>/assets/js/shop.js?v=4.1"></script>
   </body>
</html><?php /**PATH /Applications/MAMP/htdocs/Gazing/medstore/resources/views/web/footer.blade.php ENDPATH**/ ?>