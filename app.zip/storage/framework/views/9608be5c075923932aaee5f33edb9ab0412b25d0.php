<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Hero section -->
<section class="product-details-section py-5">
    <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">

                        <div class="preview-pic tab-content">
                            <div class="tab-pane active" id="pic-1">
                                <img src="<?php echo e(asset('public/admin/images').'/'.$singaldata->image ?? ''); ?>" alt="product image" />
                            </div>
                        <?php
                            $gallery = DB::table('gallery')->where('productid',$singaldata->id)->get();
                            $i = 1;
                        ?>
                           <?php if($gallery->count() > 0): ?>
                              <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsgallrty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane" id="pic-<?php echo e($i++); ?>"><img src="<?php echo e(asset('public/admin/images').'/'.$itemsgallrty->image ?? ''); ?>" alt="product image" /></div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <ul class="preview-thumbnail nav nav-tabs">
                            <li class="active"><a data-target="#pic-1" data-toggle="tab"><img src="<?php echo e(asset('public/admin/images').'/'.$singaldata->image); ?>" alt="product image" /></a></li>
                            <?php if($gallery->count()> 0): ?>
                                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsgallrty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a data-target="#pic-<?php echo e($i++); ?>" data-toggle="tab"><img src="<?php echo e(asset('public/admin/images').'/'.$itemsgallrty->image ?? ''); ?>" alt="product image" /></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>

                    </div>
                    <div class="details col-md-6">
                        <h3 class="product-title"><?php echo e($singaldata->title ?? ''); ?></h3>
                        <div class="rating mb-3">
                            <div class="stars">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            </div>
                            <span class="review-no">41 reviews</span>
                        </div>
                        <p class="product-description"><?= $singaldata->shortdescription ?? '' ?></p>
                        <h4 class="price">current price: <span>$<?php echo e($singaldata->price ?? ''); ?> – $<?php echo e($singaldata->mrp_price ?? ''); ?></span></h4>
                        <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>

                        <?php
                           $size = DB::table('multisize')->where('productid',$singaldata->id)->get();
                        ?>
                        <?php if($size->count()> 0): ?>
                            <table class="variations" cellspacing="0">
                                <tbody>
                                    <tr>
                                        <td class="label quantity-td"><label for="select-quantity">SELECT QUANTITY</label></td>
                                        <td class="value">
                                            <select id="select-quantity" class="" name="attribute_select-quantity" data-attribute_name="attribute_select-quantity" data-show_option_none="yes">
                                                <option value="">Choose an option</option>
                                                <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemssize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($itemssize->size ?? ''); ?>" class="attached enabled"><?php echo e($itemssize->size ?? ''); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select><a class="reset_variations" href="#" style="visibility: hidden;">Clear</a> </td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <div class="single_variation_wrap">
                            <div class="quantity">
                                <label class="screen-reader-text ml-5" for="quantity_6218afe6b0631">Liquid Nicotine quantity</label>
                                <div class="div-container row ml-5 mr-5">

                                    <form class="AddCart"  method="post" enctype='multipart/form-data'>
                                        <?php echo csrf_field(); ?>
                                        <?php
                                        $digits = 4;
                                        ?>
                                        <input type="number" name="qty" id="quantity_6218afe6b0631" class="input-text qty text product-input col-7" step="1" min="1" max="" name="quantity" value="1" title="Qty" size="4" placeholder="" inputmode="numeric">
                                        <input type="text" name="cartid" class="cartid" value="<?php echo e(rand(pow(10, $digits-1), pow(10, $digits)-1)); ?>">
                                        <input type="text" name="image" value="<?php echo e(asset('public/admin/images')); ?>/<?php echo e($singaldata->image ?? ''); ?>">
                                        <input name="title" class="title" type="text" value="<?php echo e($singaldata->title ?? ''); ?>">
                                        <input name="price" class="price" type="text" value="<?php if(empty($singaldata->price)): ?><?php echo e($singaldata->mrp_price); ?> <?php else: ?> <?php echo e($singaldata->price); ?> <?php endif; ?> ">
                                        <input type="text" class="id" name="id" value="<?php echo e($singaldata->id ?? ''); ?>">
                                        <button type="submit" class="single_add_to_cart_button button alt disabled wc-variation-selection-needed product-button col-5">Add to cart<i class="ml-5 fa fa-shopping-cart ml-5" aria-hidden="true"></i></button>

                                     </form>


                                </div>
                            </div>
                        </div>
                        <div class="product_meta mt-3 ml-5">
                            <span class="sku_wrapper mb-1">SKU: <span class="sku mb-1"><?php echo e($singaldata->sku ?? ''); ?></span></span>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero section -->
<section class="tab-section py-5">
    <div class="container">
        <div class="container cont-2">
            <!-- tab-section -->
            <ul class="tab-navigation">
                <li class="active">Description</li>
                <li>More Information</li>
            </ul>
            <!-- tab-section -->
            <!-- Tab-Content -->
            <div class="tab-container-area">
                <div class="tab-container py-4 px-4 bg-white">
                    <h2>Description</h2>
                    <hr>
                    <p>Our 100mg Unflavored Nicotine Base uses Nicotine USP/EP which is isolated from tobacco
                        leaves by a series of extraction and purification stages specifically developed to give
                        e-liquid manufacturers a natural (non-synthetic) superior nicotine liquid.
                    </p>
                    <p>Our Nicotine Base is shipped in leakproof HDPE bottles made from high-purity, food-grade resins.</p>
                </div>
                <div class="tab-container py-4 px-4 bg-white">
                    <h2>Additional information</h2>
                    <table class="woocommerce-product-attributes shop_attributes">
                        <tbody>
                            <tr class="woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_select-quantity">
                                <th class="woocommerce-product-attributes-item__label">SELECT QUANTITY</th>
                                <td class="woocommerce-product-attributes-item__value">
                                    <p>250 ML, 500 ML, 1000 ML</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Tab-Content -->
        </div>
    </div>
</section>
<?php
   $related = DB::table('product')->where('catid',$singaldata->catid)->get();
?>
<?php if($related->count()> 0): ?>
<section class="product-tabs related-products section-padding position-relative pb-5">
    <div class="container">
        <div class="section-title style-2 wow animate__ animate__fadeIn animated" style="visibility: visible; animation-name: fadeIn;">
            <h3>Related products</h3>
        </div>
        <!--End nav-tabs-->
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="tab-one" role="tabpanel" aria-labelledby="tab-one">
                <div class="row product-grid-4">


                    <!--end product card-->
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsrelated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="product-cart-wrap mb-30 wow animate__ animate__fadeIn animated" data-wow-delay=".1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeIn;">
                            <div class="product-img-action-wrap">
                                <div class="product-img product-img-zoom">
                                    <a href="<?php echo e(url('shop-product').'/'.$itemsrelated->slug ?? ''); ?>">
                                        <img class="default-img mb-5" src="<?php echo e(asset('public/admin/images').'/'.$itemsrelated->image ?? ''); ?>" alt="">
                                        <!-- <img class="hover-img" src="<?php echo e(asset('public/admin/images').'/'.$itemsrelated->image ?? ''); ?>" alt=""> -->
                                    </a>
                                </div>
                                
                            </div>
                            <div class="product-content-wrap">
                                <h2><a href="<?php echo e(url('shop-product').'/'.$itemsrelated->slug ?? ''); ?>"><?php echo e($itemsrelated->title ?? ''); ?></a></h2>
                                <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                        <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                </div>
                                <div class="product-card-bottom">
                                    <div class="product-price">
                                        <span>$<?php echo e($itemsrelated->price ?? ''); ?></span>
                                        <!-- <span class="old-price">$<?php echo e($itemsrelated->mrp_price ?? ''); ?></span> -->
                                    </div>
                                    <div class="add-cart">


                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- till here -->



                </div>
                <!--End product-grid-4-->
            </div>
        </div>
        <!--End tab-content-->
    </div>
</section>
<?php endif; ?>

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>

<script>

    $(function () {

        $('.AddCart').submit(function(e){
            e.preventDefault();
          var token = $(this).data("token");
             $.ajaxSetup({
                 headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                 }
             });
          $.ajax({
            type: 'post',
            url:"<?php echo e(url("addtocart")); ?>",
            data:new FormData(this),
            dataType:'JSON',
            contentType: false,
            cache: false,
            processData: false,
            success: function(data){
             if(data.status==200){
             $('.cartsss').html(data.cart);
             $('.total').html(data.total);
             }
             if(data.status==203){
                window.location = login;
             }
            }
           });
         });
        });
</script>
<?php /**PATH C:\xampp\htdocs\medstor\resources\views/web/shop.blade.php ENDPATH**/ ?>