@include('web.header')
<section class="about-us">
            <div class="container">
               <div class="row">
                  <div class="col-md-6 about-col">
                     <figure><img src="https://gazingdev.website/medstore/dynamic/public/admin/images/1649829397.jpg" alt=""></figure>
                  </div>
                  <div class="col-md-6">
                     <h2 class="mb-20">ABOUT US</h2>
                     <p class="mb-15"></p><p>WITH ALL SAID ABOVE AND COUPLE WITH THE TESTIMONIES GIVEN ON EACH PRODUCT YOU FINE IN OUR STORE. WE STAND THE BEST CHANCE FOR YOU TO BUY VALIUM ONLINE, BEST PLACE TO BUY HEROIN ONLINE, BUY OPANA ONLINE WITHOUT PRESCRIPTION. HOW EVER YOU CAN ALSO BUY ALL PAINKILLERS ONLINE, ORDER FENTANYL PATCHES ONLINE SAFE AND LEGIT. WHEN SHOPPING WITH US, YOU CAN REST GUARANTEED THAT YOUR REQUEST WILL BE BUNDLED ENOUGH AND ATTENTIVELY.</p>

<p>THAT IS THE MANNER BY WHICH WE ENSURE YOU GET THE MOST NOTEWORTHY NATURE OF ANY EXPLORATION COMPOUND YOU NEED. INVESTIGATE THE SUBSTANCES ACCESSIBLE IN OUR INDEX EVEN ON THE OFF CHANCE THAT YOU ARE GOING TO INQUIRE ABOUT HEROIN (OTHERWISE CALLED DIAMORPHINE), WE HAVE YOU SECURED WITH THE MOST PERFECT HEROIN AVAILABLE TO BE PURCHASED.</p><p></p>
                     <p></p>
                  </div>
               </div>
            </div>
         </section>



    @include('web.footer')
