@include('web.header')
<style>
    .error{
        color:red;
    }
</style>
    <!-- Hero section -->

    <section class="checkout-container">
        <div class="container my-5">
            <div class="row checkout-row">
                <div class="col-lg-6 col-md-7">
                    <h2 class="mb-4">Pesonal Details</h2>
                    <form class="billing-form bg-light float-start p-3" action="{{ url('placeorder') }}" method="Post">
                         @csrf
                        <div class="row g-3">
                            <h4>Billing Address</h4>
                            <div class="col-sm-6">
                                <label class="form-label">First name</label>
                                <input type="text" name="fname" class="form-control" placeholder="First Name">
                                @if($errors->has('fname'))
                                  <span class="error">Enter First Name</span>
                                @endif
                            </div>
                            <div class="col-sm-6">
                                <label class="form-label">Last name</label>
                                <input type="text" name="lname" class="form-control" placeholder="Last Name">
                                @if($errors->has('fname'))
                                <span class="error">Enter Last Name</span>
                              @endif
                            </div>
                            <div class="col-12">
                                <label class="form-label">Company name (optional)</label>
                                <input type="text" name="company" class="form-control" placeholder="Company name (optional)">
                                @if($errors->has('company'))
                                    <span class="error">Enter Company Name</span>
                                @endif
                            </div>
                            <div class="col-12">
                                <label class="form-label">Email Id</label>
                                <input type="email" name="email" class="form-control" placeholder="Email Id">
                                @if($errors->has('email'))
                                    <span class="error">Enter Email Id</span>
                                @endif
                            </div>
                            <div class="col-12">
                                <label class="form-label">Street Address</label>
                                <input type="text" name="street" class="form-control" placeholder="Street Address">
                                @if($errors->has('street'))
                                    <span class="error">Enter street</span>
                                @endif
                            </div>
                            <div class="col-12">
                                <label class="form-label">2nd Address <span class="text-muted">(Optional)</span></label>
                                <input type="text" name="address" class="form-control" placeholder="2nd Optional Address">
                                @if($errors->has('address'))
                                <span class="error">Enter Address</span>
                            @endif
                            </div>
                            <div class="col-md-5">
                                <label class="form-label">Country</label>
                                <select class="form-select" name="country">
                                    <option>Choose...</option>
                                    <option value="United States">United States</option>
                                    <option value="Algeria">Algeria</option>
                                </select>
                                @if($errors->has('country'))
                                <span class="error">Enter Country</span>
                            @endif
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">State</label>
                                <select class="form-select" name="state">
                                    <option>Choose...</option>
                                   <option value="AL">Alabama</option>
	<option value="AK">Alaska</option>
	<option value="AZ">Arizona</option>
	<option value="AR">Arkansas</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="CT">Connecticut</option>
	<option value="DE">Delaware</option>
	<option value="DC">District Of Columbia</option>
	<option value="FL">Florida</option>
	<option value="GA">Georgia</option>
	<option value="HI">Hawaii</option>
	<option value="ID">Idaho</option>
	<option value="IL">Illinois</option>
	<option value="IN">Indiana</option>
	<option value="IA">Iowa</option>
	<option value="KS">Kansas</option>
	<option value="KY">Kentucky</option>
	<option value="LA">Louisiana</option>
	<option value="ME">Maine</option>
	<option value="MD">Maryland</option>
	<option value="MA">Massachusetts</option>
	<option value="MI">Michigan</option>
	<option value="MN">Minnesota</option>
	<option value="MS">Mississippi</option>
	<option value="MO">Missouri</option>
	<option value="MT">Montana</option>
	<option value="NE">Nebraska</option>
	<option value="NV">Nevada</option>
	<option value="NH">New Hampshire</option>
	<option value="NJ">New Jersey</option>
	<option value="NM">New Mexico</option>
	<option value="NY">New York</option>
	<option value="NC">North Carolina</option>
	<option value="ND">North Dakota</option>
	<option value="OH">Ohio</option>
	<option value="OK">Oklahoma</option>
	<option value="OR">Oregon</option>
	<option value="PA">Pennsylvania</option>
	<option value="RI">Rhode Island</option>
	<option value="SC">South Carolina</option>
	<option value="SD">South Dakota</option>
	<option value="TN">Tennessee</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
	<option value="VT">Vermont</option>
	<option value="VA">Virginia</option>
	<option value="WA">Washington</option>
	<option value="WV">West Virginia</option>
	<option value="WI">Wisconsin</option>
	<option value="WY">Wyoming</option>
                                </select>
                                @if($errors->has('state'))
                                <span class="error">Enter state</span>
                            @endif
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Zip</label>
                                <input type="text" name="pincode" class="form-control" placeholder="Zip Code">
                                @if($errors->has('pincode'))
                                <span class="error">Enter Pincode</span>
                            @endif
                            </div>
                        </div>
                        <hr class="my-4">
                        <div class="form-check">
                            <input type="checkbox" name="shippingaddress" value="shipping-address" class="form-check-input" id="shipping-address" checked="">
                            <label class="form-check-label" for="shipping-address">Shipping address is the same as my billing address</label>

                        </div>
                        <div class="form-check">
                            <input type="checkbox" name="shippingaddress" value="save" class="form-check-input" id="save-details">
                            <label class="form-check-label" for="save-details">Save this full details for next time</label>
                        </div>
                        @if($errors->has('shippingaddress'))
                        <span class="error">Select shipping address</span>
                       @endif
                        <hr>
                        <h4 class="mb-3">Payment</h4>
                        <div class="my-3">
                            <div class="form-check">
                              <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked="" value="credit">
                              <label class="form-check-label" for="credit">Credit card</label>
                            </div>
                            <div class="form-check">
                              <input id="debit" name="paymentMethod" type="radio" class="form-check-input" value="Debit card">
                              <label class="form-check-label" for="debit">Debit card</label>
                            </div>
                            <div class="form-check">
                              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" value="paypal">
                              <label class="form-check-label" for="paypal">PayPal</label>
                            </div>
                            @if($errors->has('paymentMethod'))
                            <span class="error">Select paymentMethod</span>
                           @endif
                          </div>
                          <div class="row gy-3">
                            <div class="col-md-6">
                              <label for="cc-name" class="form-label">Name on card</label>
                              <input type="text" class="form-control" id="cc-name" placeholder="" name="cardname">
                              <small class="text-muted">Full name as displayed on card</small>
                              <div class="invalid-feedback">
                                Name on card is required

                              </div>
                              @if($errors->has('cardname'))
                              <span class="error">Enter Cart On Name</span>
                             @endif
                            </div>

                            <div class="col-md-6">
                              <label for="cc-number" class="form-label">Credit card number</label>
                              <input type="text" class="form-control" id="cc-number" placeholder="" name="cardnumber">
                              <div class="invalid-feedback">
                                Credit card number is required
                              </div>
                              @if($errors->has('cardname'))
                              <span class="error">Enter Card Number</span>
                             @endif
                            </div>

                            <div class="col-md-3">
                              <label for="cc-expiration" class="form-label">Expiration</label>
                              <input type="text" class="form-control" id="cc-expiration" placeholder="" name="expiration">
                              <div class="invalid-feedback">
                                Expiration date required
                              </div>
                              @if($errors->has('expiration'))
                              <span class="error">Enter Card Expiration</span>
                             @endif
                            </div>

                            <div class="col-md-3">
                              <label for="cc-cvv" class="form-label">CVV</label>
                              <input type="text" class="form-control" id="cc-cvv" placeholder="" name="cvv">
                              <div class="invalid-feedback">
                                Security code required
                              </div>
                              @if($errors->has('cvv'))
                              <span class="error">Enter Card cvv</span>
                             @endif
                            </div>
                          </div>
                          <hr class="my-4">
                          <button class="w-100 btn btn-primary btn-lg" type="submit">Place Order</button>
                    </form>
                </div>
                <div class="col-md-5 col-lg-4 order-md-last">
                    <h4 >Your Cart<i class="fa fa-shopping-cart ml-5"></i></h4>
                    <ul class="list-group mb-3">
                @php
                    $total = 0;
                @endphp
                @if($cart->count()> 0)
                    @foreach($cart as $items)
                      <?php $total += $items->price*$items->qty; ?>
                        <li class="list-group-item d-flex justify-content-between bg-light">
                            <div class="text-success">
                            <h6 class="my-0">{{ $items->title ?? '' }}</h6>
                            </div>
                            <span class="text-success">${{ $items->price }}</span>
                        </li>
                      @endforeach
                @endif


                      <li class="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>${{ $total ?? '' }}</strong>
                      </li>
                    </ul>

                    {{--  <form class="card p-2">
                      <div class="input-group">
                        <input type="text" class="form-control redeem-input" placeholder="Promo code">
                        <button type="submit" class="btn btn-secondary redeem-button">Redeem</button>
                      </div>
                    </form>  --}}
                  </div>
            </div>
        </div>
    </section>
  @include('web.footer')
