@include('web.header')
<!-- Hero section -->
    <section class="cart-main py-5">
        @if(\Session::has('success'))
        <div class="alert alert-info">
           {!! \Session::get('success') !!} </ul>
        </div>
        @endif
        <div class="container">
            <h1>Shopping Cart</h1>

            <div class="shopping-cart">

            <div class="column-labels">
                <label class="product-image">Image</label>
                <label class="product-details">Product</label>
                <label class="product-price">Price</label>
                <label class="product-quantity">Quantity</label>
                <label class="product-removal">Remove</label>
                <label class="product-line-price">Total</label>
            </div>
            @php
                $total = 0;
            @endphp
           @if($cart->count()> 0)
            @foreach($cart as $itemcart)
                @php
                    $total += $itemcart->price*$itemcart->qty;
                @endphp
                <div class="product">
                    <div class="product-image">
                        <img src="{{ $itemcart->image ?? '' }}">
                    </div>
                    <div class="product-details">
                        <div class="product-title">{{ $itemcart->title ?? '' }}</div>

                    </div>
                    <div class="product-price">{{ $itemcart->price ?? '' }}</div>
                    <div class="product-quantity">
                        <input type="number" value="1" min="1">
                    </div>
                    <div class="product-removal">
                        <a href="{{ url('remove').'/'.$itemcart->id ?? '' }}" class="remove-product">
                            Remove
                        </a>
                    </div>
                    <div class="product-line-price">{{ $itemcart->qty*$itemcart->price  }}</div>
                </div>
            @endforeach
        @endif



            <div class="totals">
                <div class="totals-item">
                 <label>Subtotal</label>
                <div class="totals-value" id="cart-subtotal">{{ $total ?? '' }}</div>
                </div>
                <div class="totals-item">
                    @php
                        $new_width = (5 / 100) * $total;
                    @endphp
                <label>Tax (5%)</label>
                <div class="totals-value" id="cart-tax">{{ $total-$new_width ?? '' }}</div>
                </div>
                <div class="totals-item">
                <label>Shipping</label>
                <div class="totals-value" id="cart-shipping">15</div>
                </div>
                <div class="totals-item totals-item-total">
                <label>Grand Total</label>
                <div class="totals-value" id="cart-total">{{ $total+15+$new_width }}</div>
                </div>
            </div>
                <a href="{{ url('checkout') }}" class="checkout">Proceed to checkout</a>
            </div>
        </div>
    </section>
    <!-- Hero section -->

    @include('web.footer')
